import pyautogui as pg
while True:
    pg.displayMousePosition()